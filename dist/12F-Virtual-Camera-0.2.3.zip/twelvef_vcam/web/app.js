'use strict';
const $ = id => document.getElementById(id);
const token = new URLSearchParams(location.hash.slice(1)).get('token');
history.replaceState(null,'',location.pathname);
let socket, paired=false, seq=0, session, retry, userConnected=false;
let position=[0,0,0], rotation=[0,0,0,1], sensor=false, last=performance.now(), previewURL;
const held=new Map();
function status(text){$('status').textContent=text;}
function send(type,payload={}) {
  if(paired && socket.readyState===WebSocket.OPEN) socket.send(JSON.stringify({v:1,type,session,seq:seq++,t:performance.now()/1000,payload}));
}
function connect(){
  if(!token){status('Missing pairing token. Scan the QR code again.');return;}
  clearTimeout(retry); paired=false; seq=0; session=crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
  socket=new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/ws`);
  socket.binaryType='blob'; status('Connecting…');
  socket.onopen=()=>socket.send(JSON.stringify({token}));
  socket.onmessage=event=>{
    if(event.data instanceof Blob){
      if(previewURL)URL.revokeObjectURL(previewURL);
      previewURL=URL.createObjectURL(event.data);$('preview').src=previewURL;$('preview').style.display='block';$('empty').hidden=true;return;
    }
    const msg=JSON.parse(event.data);
    if(msg.type==='state' && msg.payload.status)status(`${msg.payload.status} · ${msg.payload.quality}`);
    if(msg.type==='paired'){paired=true;send('hello',{client:'browser',capabilities:['manual','orientation']});status('Connected · manual movement');}
  };
  socket.onclose=event=>{paired=false;held.clear();status(`Disconnected (${event.reason||event.code}). Recording stops in Blender.`);if(userConnected && event.code!==1008)retry=setTimeout(connect,2000);};
  socket.onerror=()=>status('Connection failed. Check LAN address, firewall and certificate trust.');
}
$('connect').onclick=()=>{if(socket && socket.readyState<2)socket.close();userConnected=true;connect();};
document.querySelectorAll('[data-command]').forEach(button=>button.onclick=()=>send('command',{name:button.dataset.command}));
for(const name of ['lens','focus','aperture','scale']) $(name).oninput=()=>{
  const value=Number($(name).value);if(Number.isFinite(value))send('settings',{[name]:value});
  if(name==='lens')$('lensValue').textContent=`${value} mm`;
};
// Intrinsic Y-X-Z manual rotation in the ARKit camera basis.
function quaternion(yaw,pitch,roll){
  const h=Math.PI/360, x=pitch*h,y=yaw*h,z=roll*h;
  const sx=Math.sin(x),cx=Math.cos(x),sy=Math.sin(y),cy=Math.cos(y),sz=Math.sin(z),cz=Math.cos(z);
  return [cy*sx*cz+sy*cx*sz,sy*cx*cz-cy*sx*sz,cy*cx*sz-sy*sx*cz,cy*cx*cz+sy*sx*sz];
}
for(const name of ['pan','tilt','roll'])$(name).oninput=()=>{sensor=false;rotation=quaternion(+$('pan').value,+$('tilt').value,+$('roll').value);$('badge').textContent='MANUAL CONTROL';};
$('motion').onclick=async()=>{
  try{
    if(!window.isSecureContext)throw Error('Orientation needs trusted HTTPS. Use manual controls for now.');
    if(!window.DeviceOrientationEvent)throw Error('Orientation API unavailable');
    if(DeviceOrientationEvent.requestPermission && await DeviceOrientationEvent.requestPermission()!=='granted')throw Error('Motion permission denied');
    sensor=true; status('Orientation enabled · translation remains manual');
  }catch(error){status(error.message);}
};
window.addEventListener('deviceorientation',e=>{
  if(!sensor || e.alpha===null || e.beta===null || e.gamma===null)return;
  // W3C intrinsic Z-X-Y angles, converted by quaternion multiplication.
  const h=Math.PI/360;
  const mul=(a,b)=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]];
  rotation=mul(mul([0,0,Math.sin(e.alpha*h),Math.cos(e.alpha*h)],[Math.sin(e.beta*h),0,0,Math.cos(e.beta*h)]),[0,Math.sin(e.gamma*h),0,Math.cos(e.gamma*h)]);
  $('badge').textContent='ORIENTATION + MANUAL POSITION';
});
document.querySelectorAll('[data-axis]').forEach(button=>{
  button.onpointerdown=e=>{button.setPointerCapture(e.pointerId);held.set(e.pointerId,[+button.dataset.axis,+button.dataset.direction]);};
  button.onpointerup=button.onpointercancel=button.onlostpointercapture=e=>held.delete(e.pointerId);
});
setInterval(()=>{
  const now=performance.now(),dt=Math.min((now-last)/1000,.1);last=now;
  for(const [axis,direction] of held.values())position[axis]+=direction*dt;
  if(!document.hidden)send('pose',{position,rotation,quality:'manual'});
},33);
setInterval(()=>send('heartbeat'),2000);
document.addEventListener('visibilitychange',()=>{held.clear();if(document.hidden)send('command',{name:'stop'});});
window.addEventListener('pagehide',()=>{userConnected=false;send('command',{name:'stop'});if(socket)socket.close();});
