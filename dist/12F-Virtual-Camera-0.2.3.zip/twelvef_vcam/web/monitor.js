'use strict';
const $ = id => document.getElementById(id);
let socket, imageURL, retry, heartbeat, lastFrame = 0, lastReceived = 0, fps = 0, authenticated = false;
function connect() {
  clearTimeout(retry); clearInterval(heartbeat);
  const token = new URLSearchParams(location.hash.slice(1)).get('token');
  if (!token) { $('access').hidden = false; $('connection').textContent = 'Monitor link required'; return; }
  $('access').hidden = true;
  const current = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/ws`);
  socket = current; current.binaryType = 'blob'; authenticated = false;
  current.onopen = () => current.send(JSON.stringify({role:'viewer', token}));
  current.onmessage = event => {
    if (current !== socket) return;
    if (event.data instanceof Blob) {
      const now = performance.now();
      if (lastFrame) fps = fps ? fps * 0.9 + 100 / Math.max(1, now-lastFrame) : 1000 / Math.max(1,now-lastFrame);
      lastFrame = now; lastReceived = now;
      const previous = imageURL; imageURL = URL.createObjectURL(event.data);
      $('preview').src = imageURL; $('preview').hidden = false; $('preview').style.opacity = '1'; $('waiting').hidden = true;
      if (previous) URL.revokeObjectURL(previous);
      $('fps').textContent = `${Math.round(fps)} fps`; return;
    }
    const message = JSON.parse(event.data);
    if (message.type === 'paired') {
      authenticated = true; $('connection').textContent = 'Connected · read-only';
      heartbeat = setInterval(() => { if (current.readyState === WebSocket.OPEN) current.send(JSON.stringify({type:'heartbeat'})); },2000);
    }
    if (message.type === 'state') {
      const state = message.payload;
      $('source').textContent = state.monitor_source === 'TAKE' ? `TAKE · frame ${state.review_frame}` : (state.recording ? '● RECORDING' : 'LIVE');
      $('camera').textContent = state.camera || '';
      const rows = state.takes || []; $('empty').hidden = rows.length > 0;
      $('takes').replaceChildren(...rows.map(take => {
        const row = document.createElement('li'); row.textContent = take.label;
        if (state.monitor_source === 'TAKE' && state.selected_take === take.id) row.className = 'active';
        const detail = document.createElement('span'); detail.textContent = `${((take.end-take.start)/take.fps).toFixed(1)} s · ${take.fps.toFixed(2)} fps`;
        row.append(detail); return row;
      }));
    }
  };
  current.onclose = event => {
    if (current !== socket) return;
    clearInterval(heartbeat);
    $('connection').textContent = event.code === 1008 ? 'Access rejected or viewer limit reached. Request a fresh monitor link.' : 'Disconnected · reconnecting…';
    if (event.code !== 1008) retry = setTimeout(connect,2000);
    else $('access').hidden = false;
    authenticated = false;
  };
  current.onerror = () => { $('connection').textContent = 'Cannot reach Blender. Check Wi-Fi and firewall.'; };
}
$('access').onsubmit = event => {
  event.preventDefault();
  try {
    const url = new URL($('link').value.trim());
    if (url.origin !== location.origin || url.pathname !== '/monitor') throw Error('foreign link');
    location.hash = url.hash; if (socket) { const old = socket; socket = null; old.close(); } connect();
  } catch { $('connection').textContent = 'Paste the monitor link for this Blender computer.'; }
};
$('fullscreen').onclick = () => { if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen(); };
setInterval(() => {
  if (!lastReceived || performance.now()-lastReceived > 2500) {
    $('fps').textContent = '0 fps'; $('preview').style.opacity = '0.3'; $('waiting').hidden = false;
    $('waiting').textContent = authenticated ? 'Preview paused or unavailable in Blender' : 'Waiting for Blender preview';
  }
},500);
window.addEventListener('pagehide',() => { clearTimeout(retry); clearInterval(heartbeat); if(socket) socket.close(); if(imageURL)URL.revokeObjectURL(imageURL); });
connect();
