"""Artist storage resolution, independent of Blender and source repositories."""
from pathlib import Path

def resolve_storage(blend_file: str, override: str, user_data: Path, session_id: str) -> Path:
    if override.strip(): return Path(override).expanduser().resolve()
    if blend_file:
        blend = Path(blend_file).resolve()
        return blend.parent/(blend.stem+'.12f')
    return user_data/'12F Virtual Camera'/'Unsaved'/session_id
