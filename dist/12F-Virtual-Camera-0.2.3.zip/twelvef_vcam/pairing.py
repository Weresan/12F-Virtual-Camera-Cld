"""LAN-only pairing URL selection. Never advertise loopback to a phone."""
import ipaddress
import socket
import struct
import zlib

def qr_png(matrix, scale=8):
    """Encode a QR boolean matrix as RGB PNG without image dependencies."""
    size = len(matrix)
    if not size or any(len(row) != size for row in matrix): raise ValueError('Square QR matrix required')
    def chunk(kind,data):
        return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data)&0xffffffff)
    rows = []
    for row in matrix:
        pixels = b''.join((b'\x00\x00\x00' if bit else b'\xff\xff\xff')*scale for bit in row)
        rows.extend([b'\x00'+pixels]*scale)
    dimension = size*scale
    return (b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',dimension,dimension,8,2,0,0,0))+
        chunk(b'IDAT',zlib.compress(b''.join(rows)))+chunk(b'IEND',b''))

def lan_address(value):
    try: address = ipaddress.IPv4Address(value.strip())
    except ipaddress.AddressValueError: raise ValueError('Enter the computer Wi-Fi IPv4 address, for example 192.168.1.20')
    if address.is_loopback or address.is_unspecified or address.is_multicast or address.is_link_local or int(address) == 0xffffffff:
        raise ValueError('Phone pairing needs a reachable LAN IPv4 address; loopback and wildcard addresses cannot be used')
    return str(address)

def detect_lan_address():
    # UDP connect chooses an OS route without sending packets or contacting a server.
    candidates = []
    try:
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
            sock.connect(('192.0.2.1',9))
            candidates.append(sock.getsockname()[0])
    except OSError: pass
    try: candidates.extend(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError: pass
    for value in candidates:
        try: return lan_address(value)
        except ValueError: pass
    raise ValueError('No LAN address detected. Set LAN IP to the computer Wi-Fi IPv4 address and try again')

def phone_host(value):
    if value.strip().lower() in ('','auto','localhost','127.0.0.1','::1'):
        return detect_lan_address()
    return lan_address(value)

def pairing_page(url, svg):
    import html
    safe = html.escape(url,quote=True)
    return ('<!doctype html><html><head><meta charset="utf-8"><meta name="referrer" content="no-referrer">'
        '<title>12F · Pair your phone</title><style>body{font:18px system-ui;background:#121719;color:#eee;'
        'max-width:760px;margin:40px auto;padding:24px}svg{background:white;width:320px;height:320px;'
        'padding:16px}code{overflow-wrap:anywhere}p{line-height:1.6}</style></head><body>'
        '<h1>12F Virtual Camera</h1><h2>Scan this QR on your iPhone</h2>'
        '<p>Keep this computer on this pairing page. The controller belongs on your phone. '
        'Both devices must use the same local network.</p>'+svg+
        '<p>On the phone, open the scanned link and tap <strong>Connect to Blender</strong>.</p>'
        '<p>If you already connected the computer controller, close that tab, stop/start the Blender server, '
        'then scan this new QR.</p><p>Phone URL (keep private):<br><code>'+safe+'</code></p>'
        '<p>If Safari cannot reach this address, check the LAN IP, private-network firewall access '
        'for Blender, and Wi-Fi client isolation. Stop the server to revoke this link.</p></body></html>')
