"""Main-thread GPU camera monitor. Never render or access bpy on the socket thread."""
import time
import bpy
import gpu

class CameraPreview:
    def __init__(self):
        self.offscreen = None
        self.image = None
        self.encoding_scene = None
        self.size = None
        self.next_capture = 0
        self.last_capture = None
        self.fps = 0.0
        self.status = 'Waiting for a controller'
        self.error = ''

    def close(self):
        if self.offscreen is not None:
            self.offscreen.free(); self.offscreen = None
        if self.image is not None:
            bpy.data.images.remove(self.image); self.image = None
        if self.encoding_scene is not None:
            bpy.data.scenes.remove(self.encoding_scene); self.encoding_scene = None
        self.size = None; self.last_capture = None; self.fps = 0

    def capture(self, scene, camera, root, width=640, fps=12, quality=65):
        now = time.monotonic()
        if now < self.next_capture: return None
        self.next_capture = now + 1/max(1,fps)
        # A visible View3D supplies its shading settings and a GPU drawing region.
        context = next(((window, area, region) for window in bpy.context.window_manager.windows
            if window.scene == scene for area in window.screen.areas if area.type == 'VIEW_3D'
            for region in area.regions if region.type == 'WINDOW'),None)
        if context is None:
            self.status = 'Open a 3D View to stream preview'; return None
        aspect = (scene.render.resolution_x*scene.render.pixel_aspect_x /
                  max(1,scene.render.resolution_y*scene.render.pixel_aspect_y))
        height = max(64, min(1280, round(width/aspect)))
        try:
            if self.size != (width,height):
                self.close()
                self.offscreen = gpu.types.GPUOffScreen(width,height,format='RGBA16F')
                self.image = bpy.data.images.new('12F Preview Buffer',width,height,alpha=True,float_buffer=True)
                self.encoding_scene = bpy.data.scenes.new('12F Preview Encoder')
                self.size = (width,height)
            encoding = self.encoding_scene
            encoding.render.image_settings.file_format = 'JPEG'
            encoding.render.image_settings.color_mode = 'RGB'
            encoding.render.image_settings.quality = quality
            # Convert scene-linear GPU output exactly once, using source display settings.
            encoding.display_settings.display_device = scene.display_settings.display_device
            for name in ('view_transform','look','exposure','gamma'):
                setattr(encoding.view_settings,name,getattr(scene.view_settings,name))
            window,area,region = context
            with bpy.context.temp_override(window=window,area=area,region=region):
                depsgraph = bpy.context.evaluated_depsgraph_get()
                evaluated = camera.evaluated_get(depsgraph)
                view = evaluated.matrix_world.inverted()
                projection = evaluated.calc_matrix_camera(depsgraph,x=width,y=height,
                    scale_x=scene.render.pixel_aspect_x,scale_y=scene.render.pixel_aspect_y)
                space = area.spaces.active
                overlays = space.overlay.show_overlays
                try:
                    space.overlay.show_overlays = False
                    self.offscreen.draw_view3d(scene,bpy.context.view_layer,space,region,
                        view,projection,do_color_management=False,draw_background=True)
                    buffer = self.offscreen.texture_color.read()
                    buffer.dimensions = width*height*4
                    self.image.pixels.foreach_set(buffer)
                finally:
                    space.overlay.show_overlays = overlays
            path = root/'recordings'/'preview.jpg'; path.parent.mkdir(parents=True,exist_ok=True)
            self.image.save_render(str(path),scene=encoding)
            data = path.read_bytes()
            completed = time.monotonic()
            if self.last_capture is not None: self.fps = 1/max(.001,completed-self.last_capture)
            self.last_capture = completed
            # Slow scenes adapt by skipping frames instead of creating a backlog.
            self.next_capture = max(self.next_capture,completed)
            self.status = f'Live {width} × {height} · {self.fps:.1f} fps'; self.error = ''
            return data
        except Exception as exc:
            self.error = str(exc); self.status = 'Preview error: '+str(exc)
            self.next_capture = time.monotonic()+2
            return None
