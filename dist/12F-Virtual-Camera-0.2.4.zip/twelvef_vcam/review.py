"""Bounded review sampling plan. Independent of Blender and transport."""
import math

def review_plan(start: int, end: int, fps: float, limit: int = 600):
    if end < start or fps <= 0 or not math.isfinite(fps) or limit < 2:
        raise ValueError('Invalid take range or sampling limit')
    duration = (end-start)/fps
    count = min(limit, max(1, math.ceil(duration*10)+1))
    frames = [start + (end-start)*i/(count-1) if count>1 else float(start) for i in range(count)]
    return {'frames':frames,'duration':duration,'fps':(count-1)/duration if duration else 1}
