"""Prepare JPEG review proxies on the main thread, restoring timeline state."""
import hashlib
import math
import uuid
from .preview import CameraPreview
from .review import review_plan

class ReviewPreviews:
    def __init__(self):
        self.preview = CameraPreview()
        self.jobs = {}
        self.session = uuid.uuid4().hex

    def close(self):
        self.preview.close(); self.jobs.clear(); self.session = uuid.uuid4().hex

    def request(self,identifier,item,camera,root):
        if identifier in self.jobs: return
        plan = review_plan(item['start'],item['end'],item['fps'])
        folder = root/'recordings'/'review-proxies'/self.session/hashlib.sha256(identifier.encode()).hexdigest()[:32]
        folder.mkdir(parents=True,exist_ok=True)
        self.jobs[identifier] = {'plan':plan,'camera':camera,'root':folder,'files':[],
            'status':'Preparing review preview','error':''}

    def tick(self,scene,service,paused=False):
        for identifier,job in self.jobs.items():
            total=len(job['plan']['frames'])
            if len(job['files']) >= total or job['error']: continue
            if paused:
                job['status']='Preparation waits until recording/playback stops'
                break
            camera=job['camera']
            try: present=camera.name in scene.objects
            except ReferenceError: present=False
            if not present:
                job['error']='Take camera is no longer in this scene'; break
            index=len(job['files']); frame=job['plan']['frames'][index]
            original=(scene.frame_current,scene.frame_subframe)
            try:
                scene.frame_set(math.floor(frame),subframe=frame-math.floor(frame))
                data=self.preview.capture(scene,camera,job['root'],480,120,65)
                if data is not None:
                    target=job['root']/f'{index:04d}.jpg'
                    target.write_bytes(data); job['files'].append(target)
                    job['status']='Ready' if len(job['files'])==total else 'Preparing review preview'
                elif self.preview.error: job['error']=self.preview.error
                else: job['status']=self.preview.status
            except Exception as exc: job['error']=str(exc)
            finally: scene.frame_set(original[0],subframe=original[1])
            break
        service.reviews = {identifier:{'files':tuple(job['files']), 'manifest':{
            'count':len(job['plan']['frames']),'available':len(job['files']),
            'fps':job['plan']['fps'],'duration':job['plan']['duration'],
            'ready':len(job['files'])==len(job['plan']['frames']),
            'status':job['error'] or job['status'],'error':bool(job['error'])}}
            for identifier,job in self.jobs.items()}
