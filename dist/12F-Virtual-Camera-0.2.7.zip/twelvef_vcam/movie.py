"""Single background encoder process; this module never imports or calls bpy."""
import json
import os
import subprocess
import threading
import time
from pathlib import Path

class ReviewMovies:
    def __init__(self):
        self.jobs={};self.lock=threading.Lock();self.process=None
        self.closing=threading.Event()

    def request(self,identifier,folder,count,fps,binary):
        with self.lock:
            if identifier in self.jobs:return
            self.jobs[identifier]={'status':'Queued for video encoding','path':None,'error':'','folder':folder,
                'count':count,'fps':fps,'binary':binary,'thread':None}

    def tick(self,paused=False):
        with self.lock:
            if paused or self.process is not None or any(j['thread'] and j['thread'].is_alive() for j in self.jobs.values()):return
            candidate=next(((key,job) for key,job in self.jobs.items() if job['thread'] is None),None)
            if candidate is None:return
            identifier,job=candidate
            job['thread']=threading.Thread(target=self._encode,args=(identifier,job),daemon=True,name='12F Review Encoder')
            job['thread'].start()

    def _encode(self,identifier,job):
        try:
            folder=job['folder'];request=folder/'encode-request.json'
            request.write_text(json.dumps({'count':job['count'],'fps':job['fps']}),encoding='utf-8')
            command=[job['binary'],'--background','--factory-startup','--threads','1','--python',str(Path(__file__).with_name('encode_review.py')),'--',str(request)]
            with (folder/'encode.log').open('wb') as log:
                with self.lock:
                    if self.closing.is_set():raise RuntimeError('Encoding cancelled')
                    job['status']='Encoding small MP4 preview'
                    process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,
                        creationflags=(subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS) if os.name=='nt' else 0)
                    self.process=process
                try:code=process.wait(timeout=300)
                except subprocess.TimeoutExpired:
                    process.kill();process.wait();raise RuntimeError('Video encoding timed out')
            path=folder/'preview.mp4'
            if code!=0 or not path.is_file():raise RuntimeError('Video encoding failed; see encode.log')
            with self.lock:job['path']=path;job['status']='MP4 ready'
        except Exception as exc:
            with self.lock:job['error']=str(exc);job['status']=str(exc)
        finally:
            with self.lock:self.process=None

    def snapshot(self,identifier):
        with self.lock:
            job=self.jobs.get(identifier)
            return {'path':job['path'],'status':job['status'],'error':job['error']} if job else {'path':None,'status':'Preparing preview frames','error':''}

    def close(self):
        self.closing.set()
        with self.lock:
            process=self.process;threads=[job['thread'] for job in self.jobs.values() if job['thread']]
        if process and process.poll() is None:process.terminate()
        for thread in threads:thread.join(timeout=10)
        with self.lock:self.jobs={};self.process=None
