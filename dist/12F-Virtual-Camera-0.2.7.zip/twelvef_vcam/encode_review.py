"""Run only in an owned factory-startup Blender subprocess, never the artist scene."""
import json
import math
import sys
from pathlib import Path
import bpy

def encode(request_path):
    request_path=Path(request_path).resolve()
    folder=request_path.parent
    request=json.loads(request_path.read_text(encoding='utf-8'))
    count=request['count'];fps=request['fps']
    if type(count) is not int or not 1<=count<=3600 or not math.isfinite(fps) or not .01<=fps<=60:
        raise ValueError('Invalid review encoding request')
    names=[f'{i:04d}.jpg' for i in range(count)]
    if not all((folder/name).is_file() for name in names):raise ValueError('Review frames incomplete')
    image=bpy.data.images.load(str(folder/names[0]))
    width,height=image.size;bpy.data.images.remove(image)
    scene=bpy.data.scenes.new('12F Review Movie')
    scene.render.resolution_x=width+width%2;scene.render.resolution_y=height+height%2
    scene.render.resolution_percentage=100
    scene.render.fps=max(1,math.ceil(fps));scene.render.fps_base=scene.render.fps/fps
    scene.frame_start=1;scene.frame_end=count
    scene.render.threads_mode='FIXED';scene.render.threads=1
    scene.view_settings.view_transform='Standard'
    editor=scene.sequence_editor_create()
    strips=editor.strips if hasattr(editor,'strips') else editor.sequences
    strip=strips.new_image('Review frames',str(folder/names[0]),channel=1,frame_start=1)
    for name in names[1:]:strip.elements.append(name)
    strip.frame_final_duration=count
    if hasattr(scene.render.image_settings,'media_type'):scene.render.image_settings.media_type='VIDEO'
    scene.render.image_settings.file_format='FFMPEG'
    scene.render.ffmpeg.format='MPEG4';scene.render.ffmpeg.codec='H264'
    scene.render.ffmpeg.constant_rate_factor='LOW'
    scene.render.ffmpeg.ffmpeg_preset='REALTIME'
    scene.render.ffmpeg.audio_codec='NONE'
    scene.render.filepath=str(folder/'encoding.mp4')
    bpy.ops.render.render(animation=True,scene=scene.name)
    output=folder/'encoding.mp4'
    if not output.is_file() or output.stat().st_size<100:raise RuntimeError('MP4 encoding produced no movie')
    output.replace(folder/'preview.mp4')

if __name__=='__main__':
    try:encode(sys.argv[sys.argv.index('--')+1])
    except Exception as exc:
        print('12F encoding failed:',exc,flush=True)
        sys.exit(1)
