'use strict';
const $ = id => document.getElementById(id);
let socket, imageURL, retry, heartbeat, lastFrame=0, lastReceived=0, fps=0, authenticated=false;
let catalog=[], catalogKey='', independent=false, reviewID='', manifest=null, poll, generation=0, sharedState={};
let playing=false, playTimer, playStart=0, playOffset=0, frameBusy=false, frameAbort, frameRequest=0;
let frameBuffer, displayedFrame=-1;
let preferred;
try { preferred=new Set(JSON.parse(localStorage.getItem('12f-preferred-takes') || '[]')); } catch { preferred=new Set(); }
const token = () => new URLSearchParams(location.hash.slice(1)).get('token');
function send(message) { if(socket && socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify(message)); }
function showImage(blob) {
  $('review-canvas').hidden=true;
  const previous=imageURL; imageURL=URL.createObjectURL(blob); $('preview').src=imageURL;
  $('preview').hidden=false; $('preview').style.opacity='1'; $('waiting').hidden=true;
  if(previous)URL.revokeObjectURL(previous);
}
function drawCatalog(force=false) {
  const key=JSON.stringify([catalog,reviewID,[...preferred]]);
  if(!force && key===catalogKey)return; catalogKey=key;
  $('empty').hidden=catalog.length>0;
  $('takes').replaceChildren(...catalog.map(take=>{
    const row=document.createElement('li'); if(reviewID===take.id)row.className='active';
    const title=document.createElement('strong'); title.textContent=take.label; row.append(title);
    const detail=document.createElement('span');detail.textContent=`${((take.end-take.start)/take.fps).toFixed(1)} s - ${take.fps.toFixed(2)} fps`;row.append(detail);
    const watch=document.createElement('button'); watch.textContent='Watch take';watch.disabled=!independent;
    watch.onclick=()=>chooseTake(take.id);row.append(watch);
    const star=document.createElement('button');star.className='preferred';star.textContent=preferred.has(take.id)?'★ Preferred':'☆ Prefer';
    star.setAttribute('aria-pressed',String(preferred.has(take.id)));
    star.onclick=()=>{
      if(preferred.has(take.id))preferred.delete(take.id);else preferred.add(take.id);
      try{localStorage.setItem('12f-preferred-takes',JSON.stringify([...preferred]));}catch{}
      drawCatalog(true);
    };row.append(star);return row;
  }));
}
function pause() { playing=false;cancelAnimationFrame(playTimer);$('play').textContent='Play'; }
function sharedLabels() {
  $('source').textContent=sharedState.monitor_source==='TAKE'?`SHARED TAKE - frame ${sharedState.review_frame}`:(sharedState.recording?'● RECORDING':'LIVE');
  $('camera').textContent=sharedState.camera||'';
}
function returnLive() {
  generation++;reviewID='';manifest=null;clearTimeout(poll);pause();if(frameAbort)frameAbort.abort();
  frameBuffer?.close();frameBuffer=null;$('review-canvas').hidden=true;$('preview').hidden=false;
  frameBusy=false;$('review-controls').hidden=true;lastReceived=0;sharedLabels();send({type:'monitor_mode',mode:'live'});drawCatalog(true);
}
async function loadFrame(index) {
  if(!manifest || !manifest.available || !frameBuffer)return;
  const id=reviewID, current=generation, request=++frameRequest;
  if(frameAbort)frameAbort.abort();frameAbort=new AbortController();frameBusy=true;
  try {
    if(manifest.ready)frameBuffer.advance(index);
    const image=await frameBuffer.get(index);if(current!==generation || request!==frameRequest)return;
    const canvas=$('review-canvas');if(canvas.width!==image.width)canvas.width=image.width;if(canvas.height!==image.height)canvas.height=image.height;
    canvas.getContext('2d').drawImage(image,0,0);canvas.hidden=false;$('preview').hidden=true;$('waiting').hidden=true;
    displayedFrame=index;$('seek').value=String(index);$('review-time').textContent=`${(index/manifest.fps).toFixed(1)} / ${manifest.duration.toFixed(1)} s`;
  }catch(error){if(error.name!=='AbortError' && current===generation){pause();$('review-status').textContent=error.message;}}
  finally{if(current===generation && request===frameRequest)frameBusy=false;}
}
async function pollManifest(current) {
  if(current!==generation || !reviewID)return;
  try {
    const response=await fetch(`/review/${encodeURIComponent(reviewID)}/manifest`,{headers:{Authorization:`Bearer ${token()}`}});
    if(response.status===403)throw Error('Monitor link expired. Request a fresh link from Blender.');
    if(response.status===404){$('review-status').textContent='Queued for preview preparation in Blender';}
    else {
      if(!response.ok)throw Error('Cannot read review preview');
      const result=await response.json();if(current!==generation)return;manifest=result;
      if(result.available && !frameBuffer){
        const id=reviewID;
        frameBuffer=new ReviewFrameBuffer(result.count,async(index,signal)=>{
          const response=await fetch(`/review/${encodeURIComponent(id)}/${index}.jpg`,{headers:{Authorization:`Bearer ${token()}`},signal});
          if(!response.ok)throw Error('Review frame unavailable');
          const blob=await response.blob();
          if(typeof createImageBitmap==='function')return createImageBitmap(blob);
          const image=new Image(),url=URL.createObjectURL(blob);image.src=url;
          await image.decode();image.close=()=>URL.revokeObjectURL(url);return image;
        });
      }
      $('review-status').textContent=`${result.status} - ${result.available}/${result.count} preview frames`;
      $('fps').textContent=`${result.fps.toFixed(1)} fps review proxy`;
      if(result.available && displayedFrame<0)loadFrame(0);
      $('seek').max=String(Math.max(1,result.count-1));$('seek').disabled=!result.ready;
      $('play').disabled=!result.ready;
      if(result.ready)frameBuffer?.advance(Number($('seek').value));
      if(result.error || result.ready)return;
    }
  }catch(error){if(current===generation)$('review-status').textContent=error.message;return;}
  poll=setTimeout(()=>pollManifest(current),500);
}
function chooseTake(id) {
  pause();clearTimeout(poll);generation++;reviewID=id;manifest=null;frameBusy=false;
  frameBuffer?.close();frameBuffer=null;displayedFrame=-1;$('review-canvas').hidden=true;$('preview').hidden=false;
  if(frameAbort)frameAbort.abort();$('review-controls').hidden=false;$('play').disabled=true;$('seek').disabled=true;$('seek').value='0';
  $('source').textContent='INDEPENDENT TAKE';$('camera').textContent=catalog.find(t=>t.id===id)?.label || 'Recorded take';
  $('waiting').hidden=false;$('waiting').textContent='Preparing independent review preview';$('preview').style.opacity='0.3';
  send({type:'monitor_mode',mode:'review'});send({type:'review',id});drawCatalog(true);pollManifest(generation);
}
function connect() {
  clearTimeout(retry);clearInterval(heartbeat);
  if(!token()){$('access').hidden=false;$('connection').textContent='Monitor link required';return;}
  $('access').hidden=true;
  const current=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/ws`);
  socket=current;current.binaryType='blob';authenticated=false;
  current.onopen=()=>current.send(JSON.stringify({role:'viewer',token:token()}));
  current.onmessage=event=>{
    if(current!==socket)return;
    if(event.data instanceof Blob){
      if(reviewID)return;
      const now=performance.now();if(lastFrame)fps=fps?fps*.9+100/Math.max(1,now-lastFrame):1000/Math.max(1,now-lastFrame);
      lastFrame=now;lastReceived=now;showImage(event.data);$('fps').textContent=`${Math.round(fps)} fps`;return;
    }
    const message=JSON.parse(event.data);
    if(message.type==='paired'){
      authenticated=true;independent=(message.capabilities||[]).includes('independent-review');$('connection').textContent='Connected - read-only';
      heartbeat=setInterval(()=>send({type:'heartbeat'}),2000);
      if(reviewID){send({type:'monitor_mode',mode:'review'});send({type:'review',id:reviewID});pollManifest(generation);}
      drawCatalog(true);
    }
    if(message.type==='review_error' && message.id===reviewID){clearTimeout(poll);$('review-status').textContent=message.status;}
    if(message.type==='state'){
      const state=message.payload;sharedState=state;catalog=state.takes||[];
      if(!reviewID)sharedLabels();
      drawCatalog();
    }
  };
  current.onclose=event=>{
    if(current!==socket)return;clearInterval(heartbeat);pause();
    $('connection').textContent=event.code===1008?'Access rejected or viewer limit reached. Request a fresh monitor link.':'Disconnected - reconnecting...';
    if(event.code!==1008)retry=setTimeout(connect,2000);else $('access').hidden=false;
    authenticated=false;
  };
  current.onerror=()=>{$('connection').textContent='Cannot reach Blender. Check Wi-Fi and firewall.';};
}
$('play').onclick=()=>{
  if(playing){pause();return;}if(!manifest?.ready)return;
  playOffset=Number($('seek').value);if(playOffset>=manifest.count-1)playOffset=0;
  playing=true;$('play').textContent='Pause';playStart=performance.now();
  let buffering=false;
  const tick=()=>{
    if(!playing)return;
    if(!manifest)return;
    const index=Math.min(manifest.count-1,playOffset+Math.floor((performance.now()-playStart)*manifest.fps/1000));
    if(!frameBuffer?.has(index)){
      if(!buffering){playOffset=index;buffering=true;frameBuffer?.advance(index);}
      if(!frameBusy)loadFrame(index);
      playStart=performance.now();$('review-status').textContent='Buffering review frames...';
    }else{
      if(buffering){playStart=performance.now();playOffset=index;buffering=false;}
      $('review-status').textContent=`Buffered playback - ${manifest.fps.toFixed(1)} fps`;
      if(!frameBusy && index!==displayedFrame)loadFrame(index);
      if(index===manifest.count-1 && displayedFrame===index){pause();return;}
    }
    playTimer=requestAnimationFrame(tick);
  };
  playTimer=requestAnimationFrame(tick);
};
$('seek').oninput=()=>{pause();loadFrame(Number($('seek').value));};
$('return-live').onclick=returnLive;
$('access').onsubmit=event=>{
  event.preventDefault();try{
    const url=new URL($('link').value.trim());if(url.origin!==location.origin || url.pathname!=='/monitor')throw Error();
    returnLive();location.hash=url.hash;if(socket){const old=socket;socket=null;old.close();}connect();
  }catch{$('connection').textContent='Paste the monitor link for this Blender computer.';}
};
$('fullscreen').onclick=()=>{if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen();};
setInterval(()=>{
  if(!reviewID && (!lastReceived || performance.now()-lastReceived>2500)){
    $('fps').textContent='0 fps';$('preview').style.opacity='0.3';$('waiting').hidden=false;
    $('waiting').textContent=authenticated?'Preview paused or unavailable in Blender':'Waiting for Blender preview';
  }
},500);
window.addEventListener('pagehide',()=>{clearTimeout(retry);clearTimeout(poll);clearInterval(heartbeat);pause();frameBuffer?.close();if(socket)socket.close();if(imageURL)URL.revokeObjectURL(imageURL);});
connect();
