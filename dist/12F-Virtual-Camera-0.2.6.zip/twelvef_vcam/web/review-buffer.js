/* Bounded decoded-frame buffer shared by browser playback and Node regression tests. */
(function(root){
  'use strict';
  class ReviewFrameBuffer {
    constructor(count,loader,options={}) {
      this.count=count;this.loader=loader;this.ahead=options.ahead||90;
      this.concurrency=options.concurrency||4;this.cache=new Map();this.pending=new Map();
      this.queue=[];this.running=0;this.cursor=0;this.closed=false;
    }
    _inside(index){return index>=Math.max(0,this.cursor-4) && index<this.cursor+this.ahead;}
    get(index,priority=true){
      if(this.closed)return Promise.reject(Error('Buffer closed'));
      if(this.cache.has(index))return Promise.resolve(this.cache.get(index));
      if(this.pending.has(index))return this.pending.get(index).promise;
      let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});
      promise.catch(()=>{});
      const job={index,promise,resolve,reject,controller:new AbortController(),started:false};
      this.pending.set(index,job);if(priority)this.queue.unshift(job);else this.queue.push(job);
      this._pump();return promise;
    }
    advance(index){
      this.cursor=index;
      for(const [key,image] of this.cache){if(!this._inside(key)){image.close?.();this.cache.delete(key);}}
      this.queue=this.queue.filter(job=>{
        if(this._inside(job.index))return true;
        this.pending.delete(job.index);job.reject(Error('Frame no longer needed'));return false;
      });
      for(let i=index;i<Math.min(this.count,index+this.ahead);i++){
        if(!this.cache.has(i) && !this.pending.has(i))this.get(i,false).catch(()=>{});
      }
    }
    has(index){return this.cache.has(index);}
    _pump(){
      while(!this.closed && this.running<this.concurrency && this.queue.length){
        const job=this.queue.shift();job.started=true;this.running++;
        Promise.resolve().then(()=>this.loader(job.index,job.controller.signal)).then(image=>{
          if(this.closed || !this._inside(job.index)){image.close?.();job.reject(Error('Frame no longer needed'));}
          else{this.cache.set(job.index,image);job.resolve(image);}
        },error=>job.reject(error)).finally(()=>{
          this.running--;this.pending.delete(job.index);this._pump();
        });
      }
    }
    close(){
      this.closed=true;for(const image of this.cache.values())image.close?.();this.cache.clear();
      for(const job of this.pending.values()){job.controller.abort();job.reject(Error('Buffer closed'));}
      this.queue=[];this.pending.clear();
    }
  }
  root.ReviewFrameBuffer=ReviewFrameBuffer;
  if(typeof module!=='undefined' && module.exports)module.exports=ReviewFrameBuffer;
})(typeof globalThis!=='undefined'?globalThis:this);
