"""Transport/tracking tolerance independent of Blender."""
class TrackingHealth:
    grace = 1.0
    timeout = 2.0
    def __init__(self): self.bad_since = None
    def observe(self,quality,received,now):
        if now-received > self.timeout: return 'stale'
        if quality in ('normal','manual'):
            self.bad_since = None; return 'valid'
        if self.bad_since is None: self.bad_since = received
        return 'expired' if received-self.bad_since >= self.grace else 'hold'

    def expired(self,now):
        return self.bad_since is not None and now-self.bad_since >= self.grace
