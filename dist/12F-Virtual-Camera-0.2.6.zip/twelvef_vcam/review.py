"""Bounded review sampling plan. Independent of Blender and transport."""
import math

def review_plan(start: int, end: int, fps: float, limit: int = 3600, target_fps: float = 30):
    if end < start or fps <= 0 or not math.isfinite(fps) or limit < 2 or not math.isfinite(target_fps) or not 1<=target_fps<=60:
        raise ValueError('Invalid take range or sampling limit')
    duration = (end-start)/fps
    count = min(limit, max(1, round(duration*target_fps)+1))
    frames = [start + (end-start)*i/(count-1) if count>1 else float(start) for i in range(count)]
    return {'frames':frames,'duration':duration,'fps':(count-1)/duration if duration else 1}
