"""12F Virtual Camera — 12Frames Studio."""
bl_info = {'name':'12F Virtual Camera','author':'12F Development Team','version':(0,2,6),
           'blender':(4,3,0),'location':'View3D > Sidebar > 12F Virtual Camera','category':'Animation'}

def register():
    from . import blender
    blender.register()

def unregister():
    from . import blender
    blender.unregister()
