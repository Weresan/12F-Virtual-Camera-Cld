"""Local HTTP/WebSocket service. No bpy imports or callbacks on this thread."""
from __future__ import annotations
import asyncio
import hmac
import json
import logging
import secrets
import ssl
import threading
import time
from http import HTTPStatus
from pathlib import Path
from queue import Queue, Full
from urllib.parse import urlsplit, unquote
from ._vendor.websockets.asyncio.server import serve
from ._vendor.websockets.http11 import Response
from ._vendor.websockets.datastructures import Headers
from .core import Stream

LOG = logging.getLogger('12f.network')
WEB = Path(__file__).parent/'web'

class Service:
    def __init__(self, host='0.0.0.0', port=8765, cert=None, key=None):
        self.host, self.port = host, port
        self.token = secrets.token_urlsafe(32)
        self.watch_token = secrets.token_urlsafe(32)
        self.viewers = set()
        self.review_requests = Queue(maxsize=64)
        self.reviews = {}
        self.events = Queue(maxsize=2048)
        self.thread = None; self.loop = None; self.active = False
        self.error = ''; self.preview = None; self.preview_lock = threading.Lock()
        self.cert, self.key = cert, key
        self.client = None
        self.state = {}

    def set_preview(self, data):
        with self.preview_lock: self.preview = data

    def start(self):
        self.ready = threading.Event()
        self.thread = threading.Thread(target=self._run, name='12F Transport', daemon=True)
        self.thread.start()
        if not self.ready.wait(5): raise RuntimeError('Server startup timeout')
        if self.error: raise RuntimeError(self.error)

    def stop(self):
        if self.loop and self.active: self.loop.call_soon_threadsafe(self.halt.set)
        if self.thread: self.thread.join(5)
        self.token = ''
        self.watch_token = ''

    def _run(self):
        try: asyncio.run(self._main())
        except Exception as exc:
            self.error = str(exc); LOG.exception('Transport failed')
        finally:
            self.active = False; self.ready.set()

    async def _main(self):
        self.loop = asyncio.get_running_loop(); self.halt = asyncio.Event()
        context = None
        if self.cert and self.key:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain(self.cert,self.key)
        async with serve(self._handle,self.host,self.port,ssl=context,process_request=self._http,
                         max_size=8192,max_queue=16,ping_interval=5,ping_timeout=10,close_timeout=1,compression=None) as server:
            self.port = server.sockets[0].getsockname()[1]
            self.active = True; self.ready.set()
            await self.halt.wait()

    def _http(self, connection, request):
        path = urlsplit(request.path).path
        if path == '/ws':
            # Browser origin must match this server. Native clients have no Origin.
            origin = request.headers.get('Origin')
            scheme = 'https' if self.cert else 'http'
            if origin and origin != scheme+'://'+request.headers.get('Host',''):
                return connection.respond(HTTPStatus.FORBIDDEN,'Origin rejected')
            return None
        if path.startswith('/review/'):
            token=request.headers.get('Authorization','')
            if not hmac.compare_digest(token,'Bearer '+self.watch_token):
                return connection.respond(HTTPStatus.FORBIDDEN,'Monitor link required')
            parts=path.split('/')
            if len(parts)!=4: return connection.respond(HTTPStatus.NOT_FOUND,'Not found')
            entry=self.reviews.get(unquote(parts[2]))
            if entry is None: return connection.respond(HTTPStatus.NOT_FOUND,'Review not prepared')
            if parts[3]=='manifest':
                body=json.dumps(entry['manifest']).encode(); mime='application/json'
            else:
                name=parts[3]
                if not name.endswith('.jpg') or not name[:-4].isdigit():
                    return connection.respond(HTTPStatus.NOT_FOUND,'Not found')
                index=int(name[:-4])
                if index>=len(entry['files']): return connection.respond(HTTPStatus.NOT_FOUND,'Frame not prepared')
                try: body=entry['files'][index].read_bytes()
                except OSError: return connection.respond(HTTPStatus.NOT_FOUND,'Frame unavailable')
                mime='image/jpeg'
            return Response(200,'OK',Headers({'Content-Type':mime,'Content-Length':str(len(body)),
                'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}),body)
        files = {'/':'index.html','/app.js':'app.js','/style.css':'style.css',
                 '/monitor':'monitor.html','/monitor.js':'monitor.js','/monitor.css':'monitor.css','/review-buffer.js':'review-buffer.js'}
        if path not in files: return connection.respond(HTTPStatus.NOT_FOUND,'Not found')
        body = (WEB/files[path]).read_bytes()
        mime = 'text/html; charset=utf-8' if path in ('/','/monitor') else ('text/javascript' if path.endswith('.js') else 'text/css')
        return Response(200,'OK',Headers({'Content-Type':mime,'Content-Length':str(len(body)),
            'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',
            'Content-Security-Policy':"default-src 'self'; connect-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; frame-ancestors 'none'"}),body)

    async def _handle(self, ws):
        owned = False
        try:
            auth = json.loads(await asyncio.wait_for(ws.recv(),5))
            if isinstance(auth,dict) and auth.get('role') == 'viewer':
                if not isinstance(auth.get('token'),str) or not hmac.compare_digest(auth['token'],self.watch_token) or len(self.viewers) >= 4:
                    await ws.close(1008,'Monitor access rejected or full'); return
                self.viewers.add(ws)
                try:
                    await ws.send(json.dumps({'type':'paired','v':1,'role':'viewer','capabilities':['independent-review']}))
                    viewer_mode={'live':True}
                    preview_task = asyncio.create_task(self._preview(ws,viewer_mode))
                    try:
                        async for data in ws:
                            message = json.loads(data)
                            if isinstance(message,dict) and message.get('type')=='monitor_mode' and message.get('mode') in ('live','review'):
                                viewer_mode['live']=message['mode']=='live'; continue
                            if isinstance(message,dict) and message.get('type')=='review' and isinstance(message.get('id'),str) and 1<=len(message['id'])<=128:
                                if not any(row.get('id')==message['id'] for row in self.state.get('takes',[])):
                                    await ws.send(json.dumps({'type':'review_error','id':message['id'],'status':'Take is no longer available'})); continue
                                try: self.review_requests.put_nowait(message['id'])
                                except Full: await ws.close(1013,'Review queue full'); break
                                continue
                            if not isinstance(message,dict) or message.get('type') != 'heartbeat':
                                await ws.close(1008,'Read-only monitor'); break
                    finally:
                        preview_task.cancel(); await asyncio.gather(preview_task,return_exceptions=True)
                finally: self.viewers.discard(ws)
                return
            if not isinstance(auth,dict) or not isinstance(auth.get('token'),str) or not hmac.compare_digest(auth['token'],self.token):
                await ws.close(1008,'Pairing rejected'); return
            if self.client is not None:
                await ws.close(1008,'Another operator is connected'); return
            self.client = ws; owned = True
            await ws.send(json.dumps({'type':'paired','v':1,'capabilities':['live-preview','preview-control','camera-state','take-browser']}))
            stream = Stream()
            preview_task = asyncio.create_task(self._preview(ws))
            try:
                async for data in ws:
                    message = json.loads(data)
                    kind, payload = stream.accept(message)
                    if kind == 'heartbeat':
                        await ws.send(json.dumps({'type':'heartbeat','echo':message['t']})); continue
                    try: self.events.put_nowait((kind,payload,time.monotonic()))
                    except Full:
                        await ws.close(1013,'Consumer overloaded; recording stopped'); break
            finally:
                preview_task.cancel()
                await asyncio.gather(preview_task,return_exceptions=True)
        except Exception as exc:
            LOG.info('Client ended: %s',type(exc).__name__)
            LOG.debug('Client exception details',exc_info=True)
            await ws.close(1008,'Invalid or disconnected stream')
        finally:
            if owned:
                self.client = None
                try: self.events.put_nowait(('disconnect',{},time.monotonic()))
                except Full: pass

    async def _preview(self, ws,viewer_mode=None):
        last = None
        last_state = None
        last_live = True
        while True:
            live=viewer_mode is None or viewer_mode['live']
            if live and not last_live: last=None
            last_live=live
            state = self.state
            if state != last_state:
                await ws.send(json.dumps({'type':'state','payload':state})); last_state = state
            with self.preview_lock: data = self.preview
            if data is not None and data is not last and live:
                await ws.send(data); last = data
            await asyncio.sleep(1/120)
