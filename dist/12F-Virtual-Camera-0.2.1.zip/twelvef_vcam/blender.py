"""All bpy use is confined to operators and the main-thread timer."""
import json
import math
import sys
import time
import uuid
from pathlib import Path
from queue import Empty
import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
from bpy.props import StringProperty, FloatProperty, BoolProperty, EnumProperty, IntProperty
from mathutils import Quaternion, Vector
from .core import Calibration, Pose, resample, smooth, save_take, sample_channel
from .server import Service
from .pairing import phone_host, qr_png
from .preview import CameraPreview
from .storage import resolve_storage

service = None
qr_previews = None
monitor = CameraPreview()
runtime = {'camera':None,'calibration':Calibration(),'raw':[],'motion':[],'optics':[],'recording':False,
           'status':'Stopped','base':None,'last':0,'journal':None,'quality':'No samples','needs_recenter':False,
           'session_root':None}

def project(scene):
    if runtime['session_root'] is not None: return runtime['session_root']
    cfg = scene.twelvef
    if not cfg.storage_id: cfg.storage_id = uuid.uuid4().hex
    override = bpy.path.abspath(cfg.output_dir) if cfg.output_dir.strip() else ''
    return resolve_storage(bpy.data.filepath,override,Path(bpy.utils.resource_path('USER'))/'datafiles',cfg.storage_id)

def close_session():
    global service
    if service: service.stop(); service = None
    monitor.close()
    if qr_previews is not None: qr_previews.clear()
    qr_path = runtime.pop('qr_path',None)
    if qr_path:
        # Only this session's unique credential file; takes and journals are retained.
        qr_path.unlink(missing_ok=True)
    runtime['session_root'] = None
    runtime['pair_url'] = ''

def camera(scene):
    cam = runtime['camera']
    if cam is None or cam.name not in scene.objects:
        source = scene.twelvef.source_camera or scene.camera
        data = source.data.copy() if source and source.type == 'CAMERA' else bpy.data.cameras.new('12F Camera')
        data.animation_data_clear()
        cam = bpy.data.objects.new('12F Camera',data)
        scene.collection.objects.link(cam)
        cam.rotation_mode = 'QUATERNION'
        cam.location = (0,0,1.6)
        cam.rotation_quaternion = Quaternion((1,0,0),math.pi/2)
        if source and source.type == 'CAMERA': cam.matrix_world = source.matrix_world.copy()
        cam['12f_owned'] = True
        runtime['camera'] = cam
    return cam

def finish(scene):
    if not runtime['recording']: return
    runtime['recording'] = False
    if runtime['journal']:
        runtime['journal'].close(); runtime['journal'] = None
    raw, motion = runtime['raw'], runtime['motion']
    take_id = runtime['take_id']
    path = runtime['take_root']/'recordings'/(take_id+'.json')
    channels = {key:[[row['t'],row[key]] for row in runtime['optics']] for key in ('lens','focus','aperture')}
    save_take(path,raw,motion,{'id':take_id,'fps':runtime['fps'],'start_frame':runtime['start_frame'],
        'shot':scene.twelvef.shot,'smoothing':scene.twelvef.smoothing},channels)
    try:
        frames = smooth(resample(motion,runtime['fps']),scene.twelvef.smoothing)
    except ValueError as exc:
        runtime['status'] = f'Raw take saved; {exc}'; return
    source = camera(scene)
    # Each take gets a separate camera + Action. Existing animation is never replaced.
    take = bpy.data.objects.new('12F '+take_id,source.data.copy())
    scene.collection.objects.link(take)
    take.rotation_mode = 'QUATERNION'; take['12f_take'] = str(path)
    take['12f_owned'] = True
    take.data.animation_data_clear()
    optics = {key:sample_channel(values,[f.t for f in frames]) for key,values in channels.items()}
    for frame,pose in enumerate(frames,start=runtime['start_frame']):
        take.location = pose.p
        take.rotation_quaternion = (pose.q[3],*pose.q[:3])
        take.keyframe_insert('location',frame=frame,group='12F Motion')
        take.keyframe_insert('rotation_quaternion',frame=frame,group='12F Motion')
        index = frame-runtime['start_frame']
        for key,property_path in (('lens','lens'),('focus','dof.focus_distance'),('aperture','dof.aperture_fstop')):
            if not optics[key]: continue
            if key == 'lens': take.data.lens = optics[key][index]
            elif key == 'focus': take.data.dof.focus_distance = optics[key][index]
            else: take.data.dof.aperture_fstop = optics[key][index]
            take.data.keyframe_insert(property_path,frame=frame,group='12F Optics')
    if take.animation_data and take.animation_data.action:
        action = take.animation_data.action
        action.name = '12F '+take_id; action.use_fake_user = True
        # Blender 4.3 legacy fcurves; newer layered Actions need slot traversal.
        if hasattr(action,'fcurves'):
            for curve in action.fcurves:
                for key in curve.keyframe_points: key.interpolation = 'LINEAR'
    runtime['status'] = 'Saved '+take_id
    if take.data.animation_data and take.data.animation_data.action:
        lens_action = take.data.animation_data.action
        lens_action.name = '12F Optics '+take_id; lens_action.use_fake_user = True
        if hasattr(lens_action,'fcurves'):
            for curve in lens_action.fcurves:
                for key in curve.keyframe_points: key.interpolation = 'LINEAR'
    scene.twelvef.take_camera = take

def command(scene,name):
    if name == 'stop': finish(scene)
    elif name == 'preview_start': scene.twelvef.live_preview = True
    elif name == 'preview_stop': scene.twelvef.live_preview = False
    elif name == 'recenter':
        if runtime['recording']: finish(scene)
        runtime['calibration'] = Calibration(); runtime['base'] = camera(scene).matrix_world.copy()
        runtime['needs_recenter'] = False
    elif name == 'record' and not runtime['recording']:
        if runtime['needs_recenter'] or time.monotonic()-runtime['last'] > .5:
            raise ValueError('Fresh tracking and recenter required before recording')
        root = project(scene); (root/'recordings').mkdir(parents=True,exist_ok=True)
        runtime['take_root'] = root
        runtime['take_id'] = time.strftime('take-%Y%m%d-%H%M%S-')+uuid.uuid4().hex[:6]
        runtime['journal'] = (root/'recordings'/(runtime['take_id']+'.jsonl')).open('x',encoding='utf-8')
        runtime['raw'] = []; runtime['motion'] = []; runtime['optics'] = []; runtime['recording'] = True
        scene.twelvef.monitor_source = 'LIVE'
        runtime['start_frame'] = scene.frame_current
        runtime['fps'] = scene.render.fps/scene.render.fps_base
        runtime['status'] = 'Recording'

def tick():
    if service is None or not service.active: return 1/120
    scene = bpy.context.scene
    try:
        for _ in range(256):
            try: kind,payload,received = service.events.get_nowait()
            except Empty: break
            if kind == 'hello':
                if runtime['recording']: finish(scene)
                command(scene,'recenter'); runtime['status'] = 'Connected'
            elif kind == 'disconnect':
                finish(scene); runtime['status'] = 'Disconnected — reconnect and recenter'
            elif kind == 'command': command(scene,payload['name'])
            elif kind == 'settings':
                cam = camera(scene)
                if 'lens' in payload: cam.data.lens = payload['lens']
                if 'focus' in payload: cam.data.dof.focus_distance = payload['focus']; cam.data.dof.use_dof = True
                if 'aperture' in payload: cam.data.dof.aperture_fstop = payload['aperture']; cam.data.dof.use_dof = True
                if 'scale' in payload: scene.twelvef.scale = payload['scale']
            elif kind == 'pose':
                runtime['last'] = received; runtime['quality'] = payload.quality
                if time.monotonic()-received > .5 or payload.quality in ('limited','lost'):
                    finish(scene); runtime['needs_recenter'] = True
                    runtime['status'] = 'Tracking interrupted — recenter'; continue
                if runtime['needs_recenter']: continue
                cam = camera(scene)
                if runtime['base'] is None: runtime['base'] = cam.matrix_world.copy()
                converted = runtime['calibration'].apply(payload,scene.twelvef.scale)
                base = runtime['base']
                # Calibration produces canonical Z-up; anchor to the artist's camera.
                anchor = base.to_quaternion() @ Quaternion((1,0,0),-math.pi/2)
                position = base.translation + anchor @ Vector(converted.p)
                rotation = anchor @ Quaternion((converted.q[3],*converted.q[:3]))
                if scene.twelvef.rig == 'TRIPOD': position = base.translation
                for i,locked in enumerate((scene.twelvef.lock_x,scene.twelvef.lock_y,scene.twelvef.lock_z)):
                    if locked: position[i] = base.translation[i]
                cam.location = position; cam.rotation_quaternion = rotation
                if runtime['recording']:
                    pose = Pose(payload.t,tuple(position),(rotation.x,rotation.y,rotation.z,rotation.w))
                    runtime['raw'].append(payload); runtime['motion'].append(pose)
                    optics = {'t':pose.t,'lens':cam.data.lens,'focus':cam.data.dof.focus_distance,'aperture':cam.data.dof.aperture_fstop}
                    runtime['optics'].append(optics)
                    runtime['journal'].write(json.dumps({'raw':payload.__dict__,'motion':pose.__dict__,'optics':optics})+'\n')
                    runtime['journal'].flush()
        if runtime['recording'] and time.monotonic()-runtime['last'] > .5:
            finish(scene); runtime['status'] = 'Pose timeout — raw take saved'
            runtime['needs_recenter'] = True
        cfg = scene.twelvef
        if cfg.live_preview and service.client is not None:
            view_camera = cfg.take_camera if cfg.monitor_source == 'TAKE' and cfg.take_camera else camera(scene)
            data = monitor.capture(scene,view_camera,project(scene),cfg.preview_width,cfg.preview_fps,cfg.preview_quality)
            if data is not None: service.set_preview(data)
        else:
            if monitor.offscreen is not None: monitor.close(); service.set_preview(None)
            monitor.status = 'Preview off' if not cfg.live_preview else 'Waiting for a controller'
        cam = cfg.take_camera if cfg.monitor_source == 'TAKE' and cfg.take_camera else camera(scene)
        service.state = {'status':runtime['status'],'recording':runtime['recording'],'quality':runtime['quality'],
            'preview_status':monitor.status,'preview_fps':round(monitor.fps,1),'preview_enabled':cfg.live_preview,
            'lens':cam.data.lens,'focus':cam.data.dof.focus_distance,'aperture':cam.data.dof.aperture_fstop,
            'shot':cfg.shot,'needs_recenter':runtime['needs_recenter'],'monitor_source':cfg.monitor_source,
            'camera':(cfg.take_camera.name if cfg.monitor_source == 'TAKE' and cfg.take_camera else cam.name)}
    except Exception as exc:
        runtime['status'] = str(exc)
        runtime['recording'] = False
        if runtime['journal']: runtime['journal'].close(); runtime['journal'] = None
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D': area.tag_redraw()
    return 1/120

class Settings(bpy.types.PropertyGroup):
    output_dir: StringProperty(name='Recording folder (optional)',subtype='DIR_PATH',description='Leave empty to use a folder beside the saved blend file; unsaved files use Blender user data. Changes apply after reconnecting')
    storage_id: StringProperty(options={'HIDDEN'})
    show_connection_options: BoolProperty(name='Connection and storage options',default=False)
    source_camera: bpy.props.PointerProperty(name='Source camera',type=bpy.types.Object,poll=lambda self,obj: obj.type == 'CAMERA')
    take_camera: bpy.props.PointerProperty(name='Recorded camera',type=bpy.types.Object,poll=lambda self,obj: obj.type == 'CAMERA' and bool(obj.get('12f_take')))
    monitor_source: EnumProperty(name='Monitor',items=[('LIVE','Live camera',''),('TAKE','Recorded camera','')],default='LIVE')
    live_preview: BoolProperty(name='Live camera monitor',default=True)
    preview_width: IntProperty(name='Preview width',default=640,min=320,max=1280)
    preview_fps: IntProperty(name='Target preview FPS',default=30,min=1,max=60,description='Requested rate; actual FPS depends on scene complexity, encoding and Wi-Fi')
    preview_quality: IntProperty(name='JPEG quality',default=65,min=20,max=95)
    root: StringProperty(options={'HIDDEN'}) # Legacy value retained for old blend-file compatibility.
    host: StringProperty(name='LAN IP',default='auto',description="Auto-detect the computer LAN IPv4 address; override with its Wi-Fi IP if the detected route uses a VPN or another adapter")
    cert: StringProperty(name='TLS certificate',subtype='FILE_PATH')
    key: StringProperty(name='TLS key',subtype='FILE_PATH')
    shot: StringProperty(name='Shot',default='Shot 001')
    scale: FloatProperty(name='Movement scale',default=1,min=.01,max=100)
    smoothing: FloatProperty(name='Take smoothing',default=0,min=0,max=.99)
    lock_x: BoolProperty(name='Lock X'); lock_y: BoolProperty(name='Lock Y'); lock_z: BoolProperty(name='Lock Z')
    rig: EnumProperty(name='Rig',items=[('HANDHELD','Handheld',''),('TRIPOD','Tripod','')])

class TWELVEF_OT_server(bpy.types.Operator):
    bl_idname='twelvef.server'; bl_label='Connect / Stop Phone'
    def execute(self,context):
        global service
        try:
            if service:
                finish(context.scene); close_session()
                runtime['status'] = 'Stopped'; return {'FINISHED'}
            root = project(context.scene); cfg = context.scene.twelvef
            root.mkdir(parents=True,exist_ok=True)
            runtime['session_root'] = root
            cfg.host = phone_host(cfg.host)
            if bool(cfg.cert) != bool(cfg.key): raise ValueError('Set both TLS certificate and key')
            service = Service(cert=bpy.path.abspath(cfg.cert) if cfg.cert else None,key=bpy.path.abspath(cfg.key) if cfg.key else None)
            service.start(); camera(context.scene)
            scheme = 'https' if cfg.cert else 'http'
            url = f'{scheme}://{cfg.host}:{service.port}/#token={service.token}'
            runtime['pair_url'] = url
            # Bundled pure-Python QR encoder; no external QR service sees credentials.
            vendor = str(Path(__file__).parent/'_vendor')
            sys.path.insert(0,vendor)
            try:
                import qrcode
                qr = qrcode.QRCode(border=4); qr.add_data(url); qr.make(fit=True)
                qr_path = root/('12f-pairing-'+uuid.uuid4().hex+'.png')
                runtime['qr_path'] = qr_path
                qr_path.write_bytes(qr_png(qr.get_matrix()))
                if qr_previews is not None:
                    qr_previews.clear()
                    qr_previews.load('phone',str(qr_path),'IMAGE')
            finally: sys.path.remove(vendor)
            runtime['status'] = 'Waiting for phone'
            if not bpy.app.background: bpy.ops.twelvef.pair('INVOKE_DEFAULT')
        except Exception as exc:
            close_session()
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}
        return {'FINISHED'}

class TWELVEF_OT_pair(bpy.types.Operator):
    bl_idname='twelvef.pair'; bl_label='Pair 12F iPhone App'
    def invoke(self,context,event):
        if not service: return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self,width=400)
    def draw(self,context):
        ui=self.layout
        ui.label(text='Open the iPhone app and tap Scan QR')
        if qr_previews is not None and 'phone' in qr_previews:
            ui.template_icon(icon_value=qr_previews['phone'].icon_id,scale=18)
        ui.label(text='Use the same Wi-Fi as this computer')
        ui.operator('twelvef.copy_link',text='Copy Pairing Link')
    def execute(self,context): return {'FINISHED'}

class TWELVEF_OT_copy_link(bpy.types.Operator):
    bl_idname='twelvef.copy_link'; bl_label='Copy Pairing Link'
    def execute(self,context):
        if not service or not runtime.get('pair_url'): return {'CANCELLED'}
        context.window_manager.clipboard = runtime['pair_url']
        return {'FINISHED'}

class TWELVEF_OT_command(bpy.types.Operator):
    bl_idname='twelvef.command'; bl_label='12F Camera Command'
    name: StringProperty()
    def execute(self,context):
        try: command(context.scene,self.name)
        except Exception as exc: self.report({'ERROR'},str(exc)); return {'CANCELLED'}
        return {'FINISHED'}

class TWELVEF_OT_snapshot(bpy.types.Operator):
    bl_idname='twelvef.snapshot'; bl_label='Send Preview Snapshot'
    def execute(self,context):
        if not service: return {'CANCELLED'}
        preview = None
        try:
            root = project(context.scene); (root/'recordings').mkdir(exist_ok=True)
            preview = bpy.data.scenes.new('12F Preview Temporary')
            for obj in context.scene.objects: preview.collection.objects.link(obj)
            preview.camera = camera(context.scene)
            preview.world = context.scene.world
            preview.render.engine = 'BLENDER_WORKBENCH'
            preview.render.resolution_x = 640; preview.render.resolution_y = 360
            preview.render.resolution_percentage = 100
            preview.render.image_settings.file_format = 'JPEG'
            path = root/'recordings'/'preview.jpg'; preview.render.filepath = str(path)
            bpy.ops.render.render(write_still=True,scene=preview.name)
            service.set_preview(path.read_bytes())
            runtime['status'] = 'Preview snapshot sent'
        except Exception as exc: self.report({'ERROR'},str(exc)); return {'CANCELLED'}
        finally:
            if preview: bpy.data.scenes.remove(preview)
        return {'FINISHED'}

class TWELVEF_OT_camera(bpy.types.Operator):
    bl_idname='twelvef.camera'; bl_label='12F Camera Selection'
    mode: StringProperty()
    def execute(self,context):
        scene = context.scene
        try:
            finish(scene)
            if self.mode == 'SOURCE':
                source = scene.twelvef.source_camera
                if source is None or source.name not in scene.objects: raise ValueError('Choose a source camera in this scene')
                cam = camera(scene)
                cam.data = source.data.copy(); cam.data.animation_data_clear()
                cam.matrix_world = source.matrix_world.copy()
                command(scene,'recenter'); scene.twelvef.monitor_source = 'LIVE'
                runtime['status'] = 'Using framing from '+source.name
            else:
                take = scene.twelvef.take_camera
                if take is None or take.name not in scene.objects: raise ValueError('Select a recorded camera in this scene')
                scene.camera = take
                for obj in context.selected_objects: obj.select_set(False)
                take.select_set(True); context.view_layer.objects.active = take
                scene.twelvef.monitor_source = 'TAKE'
                runtime['status'] = 'Reviewing '+take.name
        except Exception as exc: self.report({'ERROR'},str(exc)); return {'CANCELLED'}
        return {'FINISHED'}

class TWELVEF_PT_panel(bpy.types.Panel):
    bl_label='12F Virtual Camera'; bl_idname='TWELVEF_PT_camera'
    bl_space_type='VIEW_3D'; bl_region_type='UI'; bl_category='12F Virtual Camera'
    def draw(self,context):
        ui=self.layout; cfg=context.scene.twelvef
        ui.label(text='12Frames Studio · 0.2.1')
        ui.prop(cfg,'show_connection_options',icon='PREFERENCES',emboss=False)
        if cfg.show_connection_options:
            ui.prop(cfg,'host'); ui.prop(cfg,'cert'); ui.prop(cfg,'key'); ui.prop(cfg,'output_dir')
            ui.label(text='Default: beside .blend / Blender user data')
        if runtime['session_root'] is not None:
            ui.label(text='Storage: '+str(runtime['session_root']))
        ui.operator('twelvef.server'); ui.label(text=runtime['status']); ui.label(text=runtime['quality'])
        if service and qr_previews is not None and 'phone' in qr_previews:
            ui.operator('twelvef.pair',text='Show Pairing QR',icon='FULLSCREEN_ENTER')
            ui.label(text='iPhone app: Scan QR')
            ui.template_icon(icon_value=qr_previews['phone'].icon_id,scale=12)
        ui.prop(cfg,'shot'); ui.prop(cfg,'rig'); ui.prop(cfg,'scale'); ui.prop(cfg,'smoothing')
        ui.prop(cfg,'source_camera')
        ui.operator('twelvef.camera',text='Use Source Framing').mode = 'SOURCE'
        ui.prop(cfg,'take_camera')
        ui.operator('twelvef.camera',text='Select Recorded Camera for Review').mode = 'TAKE'
        ui.prop(cfg,'monitor_source')
        row=ui.row()
        for name in ('lock_x','lock_y','lock_z'): row.prop(cfg,name)
        for name in ('recenter','record','stop'):
            op=ui.operator('twelvef.command',text=name.title()); op.name=name
        ui.prop(cfg,'live_preview')
        if cfg.live_preview:
            ui.prop(cfg,'preview_width'); ui.prop(cfg,'preview_fps'); ui.prop(cfg,'preview_quality')
        ui.label(text=monitor.status)
        ui.operator('twelvef.snapshot')

classes=(Settings,TWELVEF_OT_server,TWELVEF_OT_pair,TWELVEF_OT_copy_link,TWELVEF_OT_command,TWELVEF_OT_snapshot,TWELVEF_OT_camera,TWELVEF_PT_panel)
@persistent
def before_load(_):
    global service
    if runtime['recording']:
        try: finish(bpy.context.scene)
        except Exception: pass # Flushed journal remains recoverable if finalization fails.
    close_session()
    runtime.update(camera=None,base=None,calibration=Calibration(),recording=False,status='Stopped after file load')

def register():
    global qr_previews
    qr_previews=bpy.utils.previews.new()
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.twelvef=bpy.props.PointerProperty(type=Settings)
    bpy.app.timers.register(tick,persistent=True)
    bpy.app.handlers.load_pre.append(before_load)

def unregister():
    global service, qr_previews
    if runtime['recording']: finish(bpy.context.scene)
    close_session()
    if qr_previews is not None:
        bpy.utils.previews.remove(qr_previews); qr_previews=None
    if bpy.app.timers.is_registered(tick): bpy.app.timers.unregister(tick)
    if before_load in bpy.app.handlers.load_pre:bpy.app.handlers.load_pre.remove(before_load)
    del bpy.types.Scene.twelvef
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
