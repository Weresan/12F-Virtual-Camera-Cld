"""Transport-independent protocol, pose math and take processing. Quaternion order: xyzw."""
from __future__ import annotations
import bisect
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path

VERSION = 1

def vector(value, length):
    if not isinstance(value, list) or len(value) != length:
        raise ValueError('Invalid vector')
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in value):
        raise ValueError('Non-finite vector')
    return tuple(float(x) for x in value)

def normalize(q):
    n = math.sqrt(sum(x*x for x in q))
    if n < 1e-9:
        raise ValueError('Zero quaternion')
    return tuple(x/n for x in q)

def multiply(a, b):
    x,y,z,w = a; X,Y,Z,W = b
    return (w*X+x*W+y*Z-z*Y, w*Y-x*Z+y*W+z*X,
            w*Z+x*Y-y*X+z*W, w*W-x*X-y*Y-z*Z)

def inverse(q):
    return (-q[0], -q[1], -q[2], q[3])

def rotate(q, p):
    return multiply(multiply(q, (*p, 0)), inverse(q))[:3]

def slerp(a,b,t):
    dot = sum(x*y for x,y in zip(a,b))
    if dot < 0:
        b = tuple(-x for x in b); dot = -dot
    if dot > .9995:
        return normalize(tuple(x+(y-x)*t for x,y in zip(a,b)))
    angle = math.acos(min(1, dot)); s = math.sin(angle)
    return tuple((math.sin((1-t)*angle)*x+math.sin(t*angle)*y)/s for x,y in zip(a,b))

@dataclass(frozen=True)
class Pose:
    t: float
    p: tuple
    q: tuple
    quality: str = 'normal'

    @classmethod
    def parse(cls, t, payload):
        quality = payload.get('quality')
        if quality not in ('normal', 'limited', 'lost', 'manual'):
            raise ValueError('Invalid tracking quality')
        return cls(t, vector(payload.get('position'),3), normalize(vector(payload.get('rotation'),4)),quality)

class Stream:
    """Reject stale/replayed messages. Each new socket must send hello first."""
    def __init__(self):
        self.session = None; self.seq = -1; self.t = -1

    def accept(self, message):
        if not isinstance(message, dict) or message.get('v') != VERSION:
            raise ValueError('Unsupported protocol')
        sid, seq, t = message.get('session'), message.get('seq'), message.get('t')
        if not isinstance(sid,str) or not 1 <= len(sid) <= 128:
            raise ValueError('Invalid session')
        if type(seq) is not int or seq < 0 or type(t) not in (int,float) or not math.isfinite(t) or t < 0:
            raise ValueError('Invalid clock/sequence')
        kind, payload = message.get('type'), message.get('payload', {})
        if not isinstance(payload, dict):
            raise ValueError('Invalid payload')
        if self.session is None:
            if kind != 'hello': raise ValueError('Hello required')
        elif sid != self.session or seq <= self.seq or t < self.t:
            raise ValueError('Stale message or session change')
        if kind == 'pose':
            result = Pose.parse(t,payload)
        elif kind == 'settings':
            limits = {'lens':(8,300), 'focus':(.01,10000), 'aperture':(.7,64), 'scale':(.01,100)}
            if not payload or set(payload) - limits.keys(): raise ValueError('Invalid settings')
            for key,value in payload.items():
                if type(value) not in (int,float) or not math.isfinite(value) or not limits[key][0] <= value <= limits[key][1]:
                    raise ValueError('Setting outside bounds')
            result = payload
        elif kind == 'command':
            if payload.get('name') not in ('recenter','record','stop','preview_start','preview_stop'): raise ValueError('Unknown command')
            result = payload
        elif kind in ('hello','heartbeat'):
            result = payload
        else:
            raise ValueError('Unknown message type')
        self.session, self.seq, self.t = sid, seq, t
        return kind, result

class Calibration:
    def __init__(self):
        self.origin = None

    def apply(self, pose, scale=1):
        if self.origin is None: self.origin = pose
        # C maps right-handed ARKit Y-up into Blender Z-up: (x,-z,y).
        c = (math.sqrt(.5),0,0,math.sqrt(.5))
        delta = tuple((a-b)*scale for a,b in zip(pose.p,self.origin.p))
        local = rotate(inverse(self.origin.q),delta)
        # Rotation is camera-local -> canonical Blender world, so left-multiply C.
        return Pose(pose.t, rotate(c,local), normalize(multiply(c,multiply(inverse(self.origin.q),pose.q))), pose.quality)

def resample(samples, fps, max_gap=.25):
    """Uniform frames, linear position + shortest-arc SLERP; reject tracking gaps."""
    if fps <= 0 or not math.isfinite(fps): raise ValueError('Invalid FPS')
    if len(samples) < 2: raise ValueError('At least two samples required')
    if any(b.t <= a.t or b.t-a.t > max_gap for a,b in zip(samples,samples[1:])):
        raise ValueError('Tracking gap: split take before generating animation')
    times = [s.t for s in samples]; start = times[0]
    result = []
    for frame in range(math.floor((times[-1]-start)*fps+1e-7)+1):
        t = start+frame/fps; i = min(max(bisect.bisect_right(times,t)-1,0),len(samples)-2)
        a,b = samples[i:i+2]; f = (t-a.t)/(b.t-a.t)
        q = slerp(a.q,b.q,f)
        if result and sum(x*y for x,y in zip(result[-1].q,q)) < 0:
            q = tuple(-x for x in q)
        result.append(Pose(t,tuple(x+(y-x)*f for x,y in zip(a.p,b.p)),q))
    return result

def smooth(samples, amount):
    """Return a derived layer; never alter raw samples."""
    if not 0 <= amount < 1: raise ValueError('Smoothing must be in [0,1)')
    out = []
    for sample in samples:
        previous = out[-1] if out else sample
        out.append(Pose(sample.t,tuple(a*amount+b*(1-amount) for a,b in zip(previous.p,sample.p)),slerp(previous.q,sample.q,1-amount),sample.quality))
    return out

def sample_channel(samples, times):
    """Interpolate scalar camera channels at the same output times as motion."""
    if not samples: return []
    if any(b[0] <= a[0] for a,b in zip(samples,samples[1:])):
        raise ValueError('Channel sample times must increase')
    stamps = [s[0] for s in samples]
    out = []
    for t in times:
        if t <= stamps[0]: out.append(samples[0][1]); continue
        if t >= stamps[-1]: out.append(samples[-1][1]); continue
        i = bisect.bisect_right(stamps,t)-1
        a,b = samples[i:i+2]; f = (t-a[0])/(b[0]-a[0])
        out.append(a[1]+(b[1]-a[1])*f)
    return out

def save_take(path: Path, raw, derived, metadata, channels=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {'v':VERSION,'metadata':metadata,'raw':[asdict(s) for s in raw], 'derived':[asdict(s) for s in derived]}
    if channels is not None: data['raw_channels'] = channels
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,allow_nan=False),encoding='utf-8')
    temporary.replace(path)
